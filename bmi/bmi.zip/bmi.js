alert("welcome to my Bmi calculator")
let name = prompt('what is your name')
alert("welcome "+ " "+  name)
let height =prompt("Your Height")
let weight = prompt("Your weight")
weight /= 1000;
let result = weight * height *height ;
alert( name + " your Bmi is " + result);
alert("Thanks for choosing us to calculate your bmi")
